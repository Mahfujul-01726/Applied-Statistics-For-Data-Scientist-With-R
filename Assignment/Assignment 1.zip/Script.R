
# =================================================== #
# Assignment 1
# Author:
# Email: 
# Date of submission:
# =================================================== #


# Task 1 ------------------------------------------------------------------
# Read the data from the folder using suitable function into a variable named "df1"
# You will find details of the variables in the excel sheet named "Data Dictionary"


# Task 2 ------------------------------------------------------------------
# Check structure of the data


# Task 3 ------------------------------------------------------------------
# See summary of the data frame


# Task 4 ------------------------------------------------------------------
# (1) Use the function unique() to see the unique categories in the Major column of the data frame.


# (2) Use the function table() to see the frequency of each category in Major column in the data frame.


# Task 5 ------------------------------------------------------------------
# Create a new data frame named df2, where the "IS" category in Major column is replaced by "Insormation Systems"


# Check frequency of categories in Major column again.


# Task 5 ------------------------------------------------------------------
# Run the following code ONLY ONCE (DO NOT CHANGE ANYTHING).
set.seed(2025)
df2$Spending[sample(nrow(df2), nrow(df2) * 0.05)] <- NA  # introduces 5% missing values
df2$`Text Messages`[sample(nrow(df2), nrow(df2) * 0.1)] <- NA  # introduces 10% missing values

# Create a function called 'data_na_count' with one argument (data) that returns 
# a vector with number of missing values in each columns





# Task 7 ------------------------------------------------------------------
# Create a new data frame named df_male that contains data for male students only.



# How many missing values are there in the Spending column of the df_male data frame?
# Your answer: 



# Task 8 ------------------------------------------------------------------
# From the df2 data frame find the top 3 students having highest GPA who are 
# unemployed and are currently in 'Senior' class





# Task 9 ------------------------------------------------------------------
# In the df2 data frame, change data type of all the character columns to factor columns
# Do not create a new data frame
# Check the data type of the columns by inspecting the data frame using str() 


# See the summary of the new data frame


# Task 10 -----------------------------------------------------------------
# Select only those students who use Laptop for study. Export this data into an Excel file.

