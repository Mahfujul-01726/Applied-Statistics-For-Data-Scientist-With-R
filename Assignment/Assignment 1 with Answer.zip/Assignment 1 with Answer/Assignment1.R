
# =================================================== #
# Assignment 1
# Author: MD MAHFUJUL KARIM SHEIKH
# Email: mahfojulemridul@gmail.com 
# Date of submission: 18-01-25
# =================================================== #


# Task 1 ------------------------------------------------------------------
# Read the data from the folder using suitable function into a variable named "df1"
# You will find details of the variables in the excel sheet named "Data Dictionary"

library(readxl)

# Read the excel file into a variable named df1
df1 <- read_excel("Data/StudentSurveyData.xlsx")

# # Define the path to the Excel file
# file_path <- "Data/StudentSurveyData.xlsx"
# 
# # Read the "Data Dictionary" sheet into a variable
# data_dictionary <- read_excel(file_path, sheet = "Data Dictionary")
# 
# # View the content of the Data Dictionary
# View(data_dictionary)




# Task 2 ------------------------------------------------------------------
# Check structure of the data

str(df1)

# Task 3 ------------------------------------------------------------------
# See summary of the data frame

summary(df1)


# Task 4 ------------------------------------------------------------------
# (1) Use the function unique() to see the unique categories in the Major column of the data frame.

# View unique categories in the Major column
unique_categories <- unique(df1$Major)

# Print the unique categories
print(unique_categories)



# (2) Use the function table() to see the frequency of each category in Major column in the data frame.

# Use the table() function to count frequencies in the Major column
major_frequencies <- table(df1$Major)

# Print the frequency table
print(major_frequencies)


# Task 5 ------------------------------------------------------------------
# Create a new data frame named df2, where the "IS" category in Major column is replaced by "Insormation Systems"

library(dplyr)
# Create a new data frame with the modified Major column
df2 <- df1 %>%
  mutate(Major = ifelse(Major == "IS", "Information Systems", Major))

# View the modified data frame
head(df2)

# Check frequency of categories in Major column again.
# Check the frequency of categories in the Major column of df2
major_frequencies_df2 <- table(df2$Major)

# Print the frequency table
print(major_frequencies_df2)


# Task 5 ------------------------------------------------------------------
# Run the following code ONLY ONCE (DO NOT CHANGE ANYTHING).
set.seed(2025)
df2$Spending[sample(nrow(df2), nrow(df2) * 0.05)] <- NA  # introduces 5% missing values
df2$`Text Messages`[sample(nrow(df2), nrow(df2) * 0.1)] <- NA  # introduces 10% missing values

# Create a function called 'data_na_count' with one argument (data) that returns 

# Create the data_na_count function
data_na_count <- function(data) {
  # Use sapply to count NA values in each column
  na_counts <- sapply(data, function(x) sum(is.na(x)))
  return(na_counts)
}


# a vector with number of missing values in each columns

# Count missing values in each column of df2
na_counts <- data_na_count(df2)

# Print the result
print(na_counts)




# Task 7 ------------------------------------------------------------------
# Create a new data frame named df_male that contains data for male students only.

library(dplyr)

# Create a new data frame for male students only
df_male <- df2 %>% 
  filter(Gender == "Male")

# View the first few rows of df_male
head(df_male)


# How many missing values are there in the Spending column of the df_male data frame?
# Count the number of missing values in the Spending column of df_male
missing_values_spending <- sum(is.na(df_male$Spending))

# Print the result
print(missing_values_spending)



# My answer: 3

# Please go to Output folder and check missing value in pratical
# 
# library(writexl)
# write.csv(df_male, "Output/df_male.csv", row.names = FALSE)


# Task 8 ------------------------------------------------------------------
# From the df2 data frame find the top 3 students having highest GPA who are 
# unemployed and are currently in 'Senior' class

library(dplyr)

# Find the top 3 students with the highest GPA who are unemployed and in Senior class
top_3_senior_unemployed <- df2 %>%
  filter(Employment == "Unemployed", Class == "Senior") %>%  # Filter for unemployed and senior students
  arrange(desc(GPA)) %>%  # Sort by GPA in descending order
  head(3)  # Get the top 3 students

# View the result
print(top_3_senior_unemployed)



# Task 9 ------------------------------------------------------------------
# In the df2 data frame, change data type of all the character columns to factor columns

# Convert all character columns to factor columns in df2
df2[] <- lapply(df2, function(x) if (is.character(x)) as.factor(x) else x)


# Do not create a new data frame
# Check the data type of the columns by inspecting the data frame using str() 
str(df2)

# See the summary of the new data frame
summary(df2)

# Task 10 -----------------------------------------------------------------
# Select only those students who use Laptop for study. Export this data into an Excel file.
# Load necessary packages
library(dplyr)
library(writexl)

# Filter students who use Laptop for study
df_laptop_study <- df2 %>%
  filter(Computer == "Laptop") 
df_laptop_study

# Export the filtered data to an Excel file
write_xlsx(df_laptop_study, "Output/df_laptop_study.xlsx")


