library(shiny)
library(DT)

ui <- fluidPage(
  selectInput("dataset", label = "Dataset", choices = ls("package:datasets")),
  verbatimTextOutput("summary"),
  DTOutput("table") # Correctly using DTOutput
)

server <- function(input, output, session) {
  output$summary <- renderPrint({
    dataset <- get(input$dataset, "package:datasets")
    summary(dataset)
  })
  
  output$table <- renderDT({ # Use renderDT for DTOutput
    dataset <- get(input$dataset, "package:datasets")
    dataset
  })
}

shinyApp(ui = ui, server = server)
